# App_Mascotas
Gian

App para calificar el uso de RecyclerView, CardView, ActionBar y manejo del flujo de la aplicación.  

Tarea para curso de Coursera "Desarrollo de aplicaciones con Android" semana 3.  
